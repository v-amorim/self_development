# Resultados Ótimos [5/5 e 4/5]:

Explicar planilha excel

# Maior problema encontrado:

Imagens com sombras
Barra de ferro no meio
Cor preta após último dígito
Confusão de letra com dígito
Confusão de dígito com letra

# Resultados e Discussões

Das 33 imagens:

- 12 imagens foram identificadas corretamente pelo modelo OCR
- 10 imagens foram identificadas contendo apenas um erro
- 03 imagens foram identificadas contendo dois erros
- 02 imagens foram identificadas contendo três erros
- 02 imagens foram identificadas contendo quatro ou mais erros
- 04 imagens praticamente não foram identificadas

# Conclusão

O modelo OCR apresentou resultados insatisfátorio, com uma taxa de acerto de 36,36% (66.66% incluíndo as de um erro).
Conclui-se que deve-se procurar ferramentas e outros filtros para melhorar o tratamento das imagens e o modelo OCR para que ele possa ser utilizado em um sistema de reconhecimento de códigos de container.
