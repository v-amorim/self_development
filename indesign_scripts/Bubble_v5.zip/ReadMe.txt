Notes:
Please look at the instructions image!

The differences in options only apply to edge cases. For most people, both actions will work all the time. Recommend option B for beginners and most use cases. Recommend option A for cleaning physical raws.
Option A (color range method): Slower, can be used to magic wand clean area outside of panels, will not fill unselected areas greater than 30px radius.
Option B (select transparency method): Faster, Cannot be used to magic wand clean area outside of panels.

Difference between v4 and v5:
Included instructions with download.

https://quicksandscans.wordpress.com/resources/